The examples directory contains a variety of scripts that do reconstruction examples or run numerical experiments. 
You must run the example scripts from the examples directory
Most scripts require Halide to be installed.
Data for the examples is located in the examples/data directory.
